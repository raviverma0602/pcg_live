<?php
declare(strict_types=1);

namespace HaartyHanks\UrlReplacer\Observer;

use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Config save hote hi FPC (built-in ya Varnish) clean, taaki change turant dikhe.
 */
class FlushPageCache implements ObserverInterface
{
    public function __construct(private readonly TypeListInterface $cacheTypeList)
    {
    }

    public function execute(Observer $observer): void
    {
        $this->cacheTypeList->cleanType('full_page');
    }
}
