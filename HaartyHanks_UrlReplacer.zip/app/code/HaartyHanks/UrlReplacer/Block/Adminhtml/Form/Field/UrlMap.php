<?php
declare(strict_types=1);

namespace HaartyHanks\UrlReplacer\Block\Adminhtml\Form\Field;

use Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray;

class UrlMap extends AbstractFieldArray
{
    protected function _prepareToRender(): void
    {
        $this->addColumn('from_url', [
            'label' => __('Old URL'),
            'class' => 'required-entry validate-url',
            'style' => 'width:420px',
        ]);
        $this->addColumn('to_url', [
            'label' => __('New URL'),
            'class' => 'required-entry validate-url',
            'style' => 'width:320px',
        ]);
        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add URL');
    }
}
