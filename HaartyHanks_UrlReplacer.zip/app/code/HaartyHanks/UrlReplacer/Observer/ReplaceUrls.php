<?php
declare(strict_types=1);

namespace HaartyHanks\UrlReplacer\Observer;

use Magento\Framework\App\Area;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Response\Http as HttpResponse;
use Magento\Framework\App\State;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Store\Model\ScopeInterface;

class ReplaceUrls implements ObserverInterface
{
    private const XML_ENABLED = 'hh_urlreplacer/general/enabled';
    private const XML_MAP     = 'hh_urlreplacer/general/mappings';

    /** URL ke turant baad ye aaye to wo URL ka hissa hai, replace nahi karna (e.g. ?p=2, /child, .html2) */
    private const BOUNDARY = '(?![\w\-/?#]|\.\w|\\\\/)';

    public function __construct(
        private readonly ScopeConfigInterface $scopeConfig,
        private readonly Json $json,
        private readonly State $appState
    ) {
    }

    public function execute(Observer $observer): void
    {
        $response = $observer->getEvent()->getResponse();
        if (!$response instanceof HttpResponse || !$this->isFrontend()) {
            return;
        }

        if (!$this->scopeConfig->isSetFlag(self::XML_ENABLED, ScopeInterface::SCOPE_STORE)) {
            return;
        }

        $map = $this->getMap();
        if (!$map || !$this->isReplaceableContent($response)) {
            return;
        }

        $body = (string) $response->getBody();
        if ($body === '') {
            return;
        }

        foreach ($map as $from => $to) {
            // normal URL + JSON escaped URL (https:\/\/...) dono handle
            $variants = [
                $from => $to,
                str_replace('/', '\/', $from) => str_replace('/', '\/', $to),
            ];
            foreach ($variants as $search => $replace) {
                if (!str_contains($body, $search)) {
                    continue;
                }
                $pattern = '~' . preg_quote($search, '~') . self::BOUNDARY . '~';
                $result  = preg_replace_callback($pattern, static fn () => $replace, $body);
                if ($result !== null) {
                    $body = $result;
                }
            }
        }

        $response->setBody($body);
    }

    private function getMap(): array
    {
        $raw = $this->scopeConfig->getValue(self::XML_MAP, ScopeInterface::SCOPE_STORE);
        if (!$raw) {
            return [];
        }

        try {
            $rows = $this->json->unserialize($raw);
        } catch (\InvalidArgumentException) {
            return [];
        }

        $map = [];
        foreach ((array) $rows as $row) {
            $from = trim((string) ($row['from_url'] ?? ''));
            $to   = trim((string) ($row['to_url'] ?? ''));
            if ($from !== '' && $to !== '' && $from !== $to) {
                $map[$from] = $to;
            }
        }

        // lambe URL pehle, taaki overlap mein galat replace na ho
        uksort($map, static fn ($a, $b) => strlen($b) <=> strlen($a));

        return $map;
    }

    private function isReplaceableContent(HttpResponse $response): bool
    {
        $header = $response->getHeader('Content-Type');
        $type   = $header ? strtolower((string) $header->getFieldValue()) : 'text/html';

        return str_contains($type, 'html') || str_contains($type, 'json');
    }

    private function isFrontend(): bool
    {
        try {
            return $this->appState->getAreaCode() === Area::AREA_FRONTEND;
        } catch (\Exception) {
            return false;
        }
    }
}
